mod; YYYY/MM/DD; HH:MM:SS; aligned
src; "Daten�bertragung DIVA2VDVExportTask"; "2026/01/22"; "09:35:38"
chs; "ISO-8859-1"
ver; "19.75.0.7411"
ifv; "Version 5.0"
dve; "Abbildung von DIVA auf das �PNV-Datenmodel 5.0/1.5"
com; "FABER"; "VBL-VW2K1256"
fft; "LIO"

tbl; EINZELANSCHLUSS
atr; BASIS_VERSION; EINAN_NR; ANSCHLUSS_NAME; ANSCHLUSS_GRUPPE; LEITSTELLENKENNUNG; ZUB_LI_NR; ZUB_LI_RI_NR; ZUB_ORT_REF_ORT; ZUB_ONR_TYP_NR; ZUB_ORT_NR; VON_ORT_REF_ORT; LinienID; RichtungsID; ASBID; ABB_LI_NR; ABB_LI_RI_NR; ABB_ORT_REF_ORT; ABB_ONR_TYP_NR; ABB_ORT_NR; NACH_ORT_REF_ORT
frm; num[9.0]; num[5.0]; char[40]; char[6]; num[3.0]; num[6.0]; num[3.0]; num[6.0]; num[2.0]; num[6.0]; num[6.0]; char[6]; char[6]; char[10]; num[6.0]; num[3.0]; num[6.0]; num[2.0]; num[6.0]; num[6.0]
end; 0

eof; 1

