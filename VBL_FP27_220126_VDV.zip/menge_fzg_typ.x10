mod; YYYY/MM/DD; HH:MM:SS; aligned
src; "Daten�bertragung DIVA2VDVExportTask"; "2026/01/22"; "09:35:38"
chs; "ISO-8859-1"
ver; "19.75.0.7411"
ifv; "Version 5.0"
dve; "Abbildung von DIVA auf das �PNV-Datenmodel 5.0/1.5"
com; "FABER"; "VBL-VW2K1256"
fft; "LIO"

tbl; MENGE_FZG_TYP
atr; BASIS_VERSION; FZG_TYP_NR; FZG_LAENGE; FZG_TYP_SITZ; FZG_TYP_STEH; FZG_TYP_TEXT; SONDER_PLATZ; STR_FZG_TYP
frm; num[9.0]; num[3.0]; num[2.0]; num[3.0]; num[3.0]; char[40]; num[3.0]; char[6]
rec;20260122;1;0;32;34;"Normalautobus";0;"NA"
rec;20260122;3;0;41;60;"Gelenkautobus";0;"GA"
rec;20260122;10;18;44;60;"Swisstrolleybus";0;"STR"
rec;20260122;11;18;63;94;"Doppelgelenktrolleybus";0;"DGT"
rec;20260122;13;0;32;34;"Elektro Normalautobus";0;"NA-E"
rec;20260122;14;0;41;60;"Elektro Gelenkautobus";0;"GA-E"
rec;20260122;15;0;26;30;"Elektro Midibus";0;"MA-E"
end; 7

eof; 1

