mod; YYYY/MM/DD; HH:MM:SS; aligned
src; "Daten�bertragung DIVA2VDVExportTask"; "2026/01/22"; "09:35:38"
chs; "ISO-8859-1"
ver; "19.75.0.7411"
ifv; "Version 5.0"
dve; "Abbildung von DIVA auf das �PNV-Datenmodel 5.0/1.5"
com; "FABER"; "VBL-VW2K1256"
fft; "LIO"

tbl; FIRMENKALENDER
atr; BASIS_VERSION; BETRIEBSTAG; BETRIEBSTAG_TEXT; TAGESART_NR
frm; num[9.0]; num[8.0]; char[40]; num[3.0]
rec;20260122;20270111;"Montag";1
rec;20260122;20270112;"Dienstag";1
rec;20260122;20270113;"Mittwoch";1
rec;20260122;20270114;"Donnerstag";1
rec;20260122;20270115;"Freitag";2
rec;20260122;20270116;"Samstag";3
rec;20260122;20270117;"Sonntag";4
end; 7

eof; 1

