mod; YYYY/MM/DD; HH:MM:SS; aligned
src; "Daten�bertragung DIVA2VDVExportTask"; "2026/01/22"; "09:35:38"
chs; "ISO-8859-1"
ver; "19.75.0.7411"
ifv; "Version 5.0"
dve; "Abbildung von DIVA auf das �PNV-Datenmodel 5.0/1.5"
com; "FABER"; "VBL-VW2K1256"
fft; "LIO"

tbl; MENGE_FAHRTART
atr; BASIS_VERSION; FAHRTART_NR; STR_FAHRTART
frm; num[9.0]; num[2.0]; char[6]
rec;20260122;1;"N"
rec;20260122;2;"DA"
rec;20260122;3;"DE"
rec;20260122;4;"Z"
end; 4

eof; 1

