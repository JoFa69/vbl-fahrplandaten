mod; YYYY/MM/DD; HH:MM:SS; aligned
src; "Daten�bertragung DIVA2VDVExportTask"; "2026/01/22"; "09:35:38"
chs; "ISO-8859-1"
ver; "19.75.0.7411"
ifv; "Version 5.0"
dve; "Abbildung von DIVA auf das �PNV-Datenmodel 5.0/1.5"
com; "FABER"; "VBL-VW2K1256"
fft; "LIO"

tbl; MENGE_ORT_TYP
atr; BASIS_VERSION; ORT_TYP_NR; ORT_TYP_TEXT
frm; num[9.0]; num[2.0]; char[40]
rec;20260122;1;"Haltestelle"
rec;20260122;2;"Betriebshof"
end; 2

eof; 1

