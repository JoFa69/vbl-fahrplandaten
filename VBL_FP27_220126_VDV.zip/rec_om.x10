mod; YYYY/MM/DD; HH:MM:SS; aligned
src; "Daten�bertragung DIVA2VDVExportTask"; "2026/01/22"; "09:35:38"
chs; "ISO-8859-1"
ver; "19.75.0.7411"
ifv; "Version 5.0"
dve; "Abbildung von DIVA auf das �PNV-Datenmodel 5.0/1.5"
com; "FABER"; "VBL-VW2K1256"
fft; "LIO"

tbl; REC_OM
atr; BASIS_VERSION; ONR_TYP_NR; ORT_NR; ORM_KUERZEL; ORMACODE; ORM_TEXT
frm; num[9.0]; num[2.0]; num[6.0]; char[6]; num[5.0]; char[40]
end; 0

eof; 1

