mod; YYYY/MM/DD; HH:MM:SS; aligned
src; "Daten�bertragung DIVA2VDVExportTask"; "2026/01/22"; "09:35:38"
chs; "ISO-8859-1"
ver; "19.75.0.7411"
ifv; "Version 5.0"
dve; "Abbildung von DIVA auf das �PNV-Datenmodel 5.0/1.5"
com; "FABER"; "VBL-VW2K1256"
fft; "LIO"

tbl; REC_UMS
atr; BASIS_VERSION; EINAN_NR; TAGESART_NR; UMS_BEGINN; UMS_ENDE; UMS_MIN; UMS_MAX; MAX_VERZ_MAN; MAX_VERZ_AUTO
frm; num[9.0]; num[5.0]; num[3.0]; num[6.0]; num[6.0]; num[5.0]; num[5.0]; num[5.0]; num[5.0]
end; 0

eof; 1

