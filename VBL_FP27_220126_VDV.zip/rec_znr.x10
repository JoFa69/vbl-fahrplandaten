mod; YYYY/MM/DD; HH:MM:SS; aligned
src; "Daten�bertragung DIVA2VDVExportTask"; "2026/01/22"; "09:35:38"
chs; "ISO-8859-1"
ver; "19.75.0.7411"
ifv; "Version 5.0"
dve; "Abbildung von DIVA auf das �PNV-Datenmodel 5.0/1.5"
com; "FABER"; "VBL-VW2K1256"
fft; "LIO"

tbl; REC_ZNR
atr; BASIS_VERSION; ZNR_NR; FAHRERKURZTEXT; SEITENTEXT; ZNR_TEXT; ZNR_CODE
frm; num[9.0]; num[4.0]; char[44]; char[160]; char[160]; char[68]
end; 0

eof; 1

