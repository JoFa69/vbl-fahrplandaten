mod; YYYY/MM/DD; HH:MM:SS; aligned
src; "Daten�bertragung DIVA2VDVExportTask"; "2026/01/22"; "09:35:38"
chs; "ISO-8859-1"
ver; "19.75.0.7411"
ifv; "Version 5.0"
dve; "Abbildung von DIVA auf das �PNV-Datenmodel 5.0/1.5"
com; "FABER"; "VBL-VW2K1256"
fft; "LIO"

tbl; MENGE_ONR_TYP
atr; BASIS_VERSION; ONR_TYP_NR; STR_ONR_TYP; ONR_TYP_TEXT
frm; num[9.0]; num[2.0]; char[6]; char[40]
rec;20260122;1;"HP";"Haltepunkt"
rec;20260122;2;"BHOF";"Betriebshofpunkt"
rec;20260122;3;"OM";"Ortsmarke"
rec;20260122;4;"LSA";"LSA-Punkt"
rec;20260122;5;"RZP";"Routenzwischenpunkt"
rec;20260122;6;"BP";"Betriebspunkt"
rec;20260122;7;"GP";"Grenzpunkt"
end; 7

eof; 1

