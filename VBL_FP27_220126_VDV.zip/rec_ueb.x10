mod; YYYY/MM/DD; HH:MM:SS; aligned
src; "Daten�bertragung DIVA2VDVExportTask"; "2026/01/22"; "09:35:38"
chs; "ISO-8859-1"
ver; "19.75.0.7411"
ifv; "Version 5.0"
dve; "Abbildung von DIVA auf das �PNV-Datenmodel 5.0/1.5"
com; "FABER"; "VBL-VW2K1256"
fft; "LIO"

tbl; REC_UEB
atr; BASIS_VERSION; BEREICH_NR; ONR_TYP_NR; ORT_NR; UEB_ZIEL_TYP; UEB_ZIEL; UEB_LAENGE
frm; num[9.0]; num[3.0]; num[2.0]; num[6.0]; num[2.0]; num[6.0]; num[6.0]
end; 0

eof; 1

