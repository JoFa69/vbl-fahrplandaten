mod; YYYY/MM/DD; HH:MM:SS; aligned
src; "Daten�bertragung DIVA2VDVExportTask"; "2026/01/22"; "09:35:38"
chs; "ISO-8859-1"
ver; "19.75.0.7411"
ifv; "Version 5.0"
dve; "Abbildung von DIVA auf das �PNV-Datenmodel 5.0/1.5"
com; "FABER"; "VBL-VW2K1256"
fft; "LIO"

tbl; BASIS_VER_GUELTIGKEIT
atr; VER_GUELTIGKEIT; BASIS_VERSION
frm; num[8.0]; num[9.0]
rec;20270111;20260122
end; 1

eof; 1

